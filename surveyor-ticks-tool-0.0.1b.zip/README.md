# surveyor-ticks

## Installation 

Install PyQt5

$ pip install PyQt5
